package Models;

public interface IDietitian {

    public void createDiet(Client client,String description) throws Exception;
    public void addDiploma(Diploma diploma);
}
